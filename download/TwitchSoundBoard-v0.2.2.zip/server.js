// =============================================
// TwitchSoundBoard – Server v0.2.2
// Lokal, kein HTTPS, kein Crash
// =============================================

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// ---- .env (falls vorhanden, kein crash wenn nicht) ----
try { require('dotenv').config(); } catch (e) {}

// ---- Pfade ----
const SOUNDS_DIR = path.join(__dirname, 'sounds');
const VIDEOS_DIR = path.join(__dirname, 'videos');
const CONFIG_PATH = path.join(__dirname, 'config.json');
const CRED_PATH = path.join(__dirname, 'credentials.enc');

[SOUNDS_DIR, VIDEOS_DIR].forEach(d => {
  try { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); } catch (e) {}
});

// ---- Logging ----
function log(lvl, msg) {
  console.log('[' + new Date().toISOString() + '] [' + lvl + '] ' + msg);
}

// ---- Config ----
let config = {};
function loadConfig() {
  try {
    config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
  } catch (e) {
    config = {
      chat_commands: {},
      settings: {
        allow_overlap: false,
        max_queue_size: 10,
        sound_volume: 0.8,
        video_volume: 0.5,
        command_prefix: '!',
        video_duration_override_ms: 5000
      }
    };
    saveConfig();
  }
}
function saveConfig() {
  try { fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2)); } catch (e) { log('ERROR', 'Config speichern: ' + e.message); }
}
loadConfig();

// ---- Verschlüsselung (AES-256-CBC) ----
// Key basiert auf fester Zeichenkette – verschlüsselt die .enc Datei auf dem Rechner
let ENC_KEY = null;
try {
  ENC_KEY = crypto.scryptSync('TwitchSoundBoard_v1', 'local_salt', 32);
} catch (e) {
  log('WARN', 'scrypt fehlgeschlagen, nutze Fallback-Key');
  ENC_KEY = crypto.createHash('sha256').update('TwitchSoundBoard_fallback_key').digest();
}

function encrypt(text) {
  try {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', ENC_KEY, iv);
    let enc = cipher.update(text, 'utf8', 'hex');
    enc += cipher.final('hex');
    return iv.toString('hex') + ':' + enc;
  } catch (e) { return text; }
}

function decrypt(raw) {
  try {
    const parts = raw.split(':');
    if (parts.length < 2) return raw;
    const iv = Buffer.from(parts[0], 'hex');
    const enc = parts.slice(1).join(':');
    const decipher = crypto.createDecipheriv('aes-256-cbc', ENC_KEY, iv);
    let dec = decipher.update(enc, 'hex', 'utf8');
    dec += decipher.final('utf8');
    return dec;
  } catch (e) { return raw; }
}

function loadCredentials() {
  try {
    const raw = fs.readFileSync(CRED_PATH, 'utf-8');
    const data = JSON.parse(raw);
    const out = {};
    for (const k in data) {
      try {
        out[k] = (data[k] && typeof data[k] === 'string' && data[k].startsWith('enc:'))
          ? decrypt(data[k].slice(4)) : data[k];
      } catch (e) { out[k] = data[k]; }
    }
    return out;
  } catch (e) { return {}; }
}

function saveCredentials(creds) {
  try {
    const data = {};
    for (const k in creds) {
      data[k] = creds[k] ? 'enc:' + encrypt(String(creds[k])) : '';
    }
    fs.writeFileSync(CRED_PATH, JSON.stringify(data, null, 2));
  } catch (e) { log('ERROR', 'Credentials speichern: ' + e.message); }
}

// ---- Multer ----
let upload = null;
try {
  const multer = require('multer');
  const storage = multer.diskStorage({
    destination: function(req, file, cb) {
      var isVid = /\.(mp4|webm|avi|mov)$/i.test(file.originalname);
      cb(null, isVid ? VIDEOS_DIR : SOUNDS_DIR);
    },
    filename: function(req, file, cb) {
      var safe = file.originalname.replace(/[^a-zA-Z0-9._\- ]/g, '_');
      cb(null, Date.now() + '_' + safe);
    }
  });
  upload = multer({
    storage: storage,
    limits: { fileSize: 50 * 1024 * 1024 },
    fileFilter: function(req, file, cb) {
      /\.(mp3|wav|ogg|m4a|mp4|webm|avi|mov)$/i.test(file.originalname)
        ? cb(null, true) : cb(new Error('Erlaubt: mp3, wav, ogg, m4a, mp4, webm'));
    }
  });
} catch (e) {
  log('ERROR', 'Multer konnte nicht geladen werden: ' + e.message);
}

// ---- YouTube/Spotify Import ----
var ytdl = null;
try {
  ytdl = require('@distube/ytdl-core');
} catch (e) {
  log('WARN', '@distube/ytdl-core nicht installiert – YouTube/Spotify Import deaktiviert');
}

function isYtUrl(url) {
  return /(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)[a-zA-Z0-9_-]{6,}/i.test(url);
}

function isSpotifyUrl(url) {
  return /spotify\.com\/track\//i.test(url);
}

function saveStreamToFile(stream, filePath) {
  return new Promise(function(resolve, reject) {
    var file = fs.createWriteStream(filePath);
    stream.pipe(file);
    file.on('finish', function() {
      file.close();
      resolve();
    });
    file.on('error', function(err) {
      try { fs.unlinkSync(filePath); } catch(e) {}
      reject(err);
    });
    stream.on('error', function(err) {
      try { fs.unlinkSync(filePath); } catch(e) {}
      reject(err);
    });
  });
}

function searchYouTubeOnInvidious(query) {
  return new Promise(function(resolve, reject) {
    var instances = [
      'https://inv.nadeko.net',
      'https://vid.puffyan.us',
      'https://invidious.fdn.fr',
      'https://yt.artemislena.eu'
    ];

    function tryInstance(idx) {
      if (idx >= instances.length) {
        return reject(new Error('YouTube-Suche fehlgeschlagen – keine Invidious-Instanz erreichbar'));
      }

      var apiUrl = instances[idx] + '/api/v1/search?q=' + encodeURIComponent(query) + '&type=video&sort_by=relevance';

      require('https').get(apiUrl, { headers: { 'User-Agent': 'TwitchSoundBoard/0.2.0' } }, function(resp) {
        if (resp.statusCode !== 200) { resp.resume(); return tryInstance(idx + 1); }
        var data = '';
        resp.on('data', function(chunk) { data += chunk; });
        resp.on('end', function() {
          try {
            var results = JSON.parse(data);
            if (Array.isArray(results) && results.length > 0) {
              var videos = results.filter(function(r) { return r.type === 'video'; });
              if (videos.length > 0) return resolve(videos[0]);
            }
            tryInstance(idx + 1);
          } catch (e) { tryInstance(idx + 1); }
        });
      }).on('error', function() { tryInstance(idx + 1); }).setTimeout(8000, function() { tryInstance(idx + 1); });
    }

    tryInstance(0);
  });
}

// ---- Invidious Download (Proxy fuer age-restricted / format-lacking Videos) ----
function downloadViaInvidious(videoId, filePath, type) {
  // type: 'video' (combined mp4) oder 'audio' (audio only)
  return new Promise(function(resolve, reject) {
    var instances = [
      'https://inv.nadeko.net',
      'https://vid.puffyan.us',
      'https://invidious.fdn.fr',
      'https://yt.artemislena.eu',
      'https://invidious.nerdvpn.de',
      'https://invidious.jing.rocks',
      'https://invidious.privacyredirect.com',
      'https://invidious.protokolla.fi'
    ];

    function tryInstance(idx) {
      if (idx >= instances.length) {
        return reject(new Error('Download ueber Invidious fehlgeschlagen – alle ' + instances.length + ' Instanzen unerreichbar'));
      }

      var inst = instances[idx];
      var infoUrl = inst + '/api/v1/videos/' + videoId + '?fields=title,lengthSeconds,formatStreams,adaptiveFormats';

      log('INFO', 'Invidious [' + (idx+1) + '/' + instances.length + ']: ' + inst);

      require('https').get(infoUrl, { headers: { 'User-Agent': 'TwitchSoundBoard/0.2.0' } }, function(resp) {
        if (resp.statusCode !== 200) {
          resp.resume();
          log('WARN', 'Invidious ' + inst + ' Status ' + resp.statusCode);
          return tryInstance(idx + 1);
        }
        var data = '';
        resp.on('data', function(chunk) { data += chunk; });
        resp.on('end', function() {
          try {
            var info = JSON.parse(data);
            var title = info.title || 'Unknown';
            var durSec = parseInt(info.lengthSeconds) || 0;
            var dlUrl = null;
            var ext = 'mp4';
            var quality = '';

            if (type === 'video') {
              // Strategie 1: formatStreams (combined video+audio)
              if (Array.isArray(info.formatStreams) && info.formatStreams.length) {
                var mp4s = info.formatStreams.filter(function(f) { return (f.type || '').indexOf('video/mp4') === 0; });
                var pick = mp4s.length ? mp4s[0] : info.formatStreams[0];
                dlUrl = pick.url;
                ext = 'mp4';
                quality = pick.qualityLabel || pick.quality || '';
              }

              // Strategie 2: /latest_version Proxy (itag 18 = 360p combined MP4, IMMER verfuegbar)
              if (!dlUrl) {
                dlUrl = inst + '/latest_version?id=' + videoId + '&itag=18&local=true';
                ext = 'mp4';
                quality = '360p (proxy)';
              }
            } else {
              // Audio only – bestes Audio aus adaptiveFormats
              if (Array.isArray(info.adaptiveFormats) && info.adaptiveFormats.length) {
                var audios = info.adaptiveFormats
                  .filter(function(f) { return f.type && f.type.indexOf('audio/') === 0; })
                  .sort(function(a, b) { return (b.bitrate || 0) - (a.bitrate || 0); });
                if (audios.length) {
                  // audio proxy URL
                  dlUrl = inst + '/latest_version?id=' + videoId + '&itag=' + audios[0].itag + '&local=true';
                  ext = (audios[0].type || 'audio/mp4').split(';')[0].split('/')[1] || 'm4a';
                  quality = Math.round((audios[0].bitrate || 0) / 1000) + 'kbps';
                }
              }
            }

            if (!dlUrl) {
              log('WARN', 'Invidious ' + inst + ': kein Format gefunden');
              return tryInstance(idx + 1);
            }

            // URL relativ -> absolut
            if (dlUrl.indexOf('http') !== 0) dlUrl = inst + dlUrl;

            var baseName = filePath.replace(/\.[^.]+$/, '');
            var finalPath = baseName + '.' + ext;

            log('INFO', 'Invidious Download: ' + inst + ' (' + quality + ', ' + ext + ')');

            var file = fs.createWriteStream(finalPath);
            require('https').get(dlUrl, {
              headers: { 'User-Agent': 'TwitchSoundBoard/0.2.0' }
            }, function(dlResp) {
              if (dlResp.statusCode !== 200) {
                file.close();
                try { fs.unlinkSync(finalPath); } catch(e) {}
                dlResp.resume();
                log('WARN', 'Invidious DL fail (' + dlResp.statusCode + '): ' + inst);
                return tryInstance(idx + 1);
              }

              // Redirects folgen (301/302)
              if (dlResp.statusCode >= 300 && dlResp.statusCode < 400 && dlResp.headers.location) {
                file.close();
                try { fs.unlinkSync(finalPath); } catch(e) {}
                var redirUrl = dlResp.headers.location;
                if (redirUrl.indexOf('http') !== 0) redirUrl = inst + redirUrl;

                var file2 = fs.createWriteStream(finalPath);
                require('https').get(redirUrl, { headers: { 'User-Agent': 'TwitchSoundBoard/0.2.0' } }, function(redirResp) {
                  if (redirResp.statusCode !== 200) {
                    file2.close();
                    try { fs.unlinkSync(finalPath); } catch(e) {}
                    redirResp.resume();
                    return tryInstance(idx + 1);
                  }
                  redirResp.pipe(file2);
                  file2.on('finish', function() {
                    file2.close();
                    resolve({ filePath: finalPath, title: title, durationSeconds: durSec, quality: quality });
                  });
                  file2.on('error', function() { try { fs.unlinkSync(finalPath); } catch(e) {} tryInstance(idx + 1); });
                  redirResp.on('error', function() { try { fs.unlinkSync(finalPath); } catch(e) {} tryInstance(idx + 1); });
                }).on('error', function() { try { fs.unlinkSync(finalPath); } catch(e) {} tryInstance(idx + 1); })
                  .setTimeout(180000, function() { try { fs.unlinkSync(finalPath); } catch(e) {} tryInstance(idx + 1); });
                return;
              }

              dlResp.pipe(file);
              file.on('finish', function() {
                file.close();
                resolve({ filePath: finalPath, title: title, durationSeconds: durSec, quality: quality });
              });
              file.on('error', function(err) { try { fs.unlinkSync(finalPath); } catch(e) {} tryInstance(idx + 1); });
              dlResp.on('error', function() { try { fs.unlinkSync(finalPath); } catch(e) {} tryInstance(idx + 1); });
            }).on('error', function() {
              try { fs.unlinkSync(finalPath); } catch(e) {}
              tryInstance(idx + 1);
            }).setTimeout(180000, function() {
              try { fs.unlinkSync(finalPath); } catch(e) {}
              log('WARN', 'Invidious DL timeout: ' + inst);
              tryInstance(idx + 1);
            });

          } catch (e) { tryInstance(idx + 1); }
        });
      }).on('error', function() { tryInstance(idx + 1); }).setTimeout(15000, function() { tryInstance(idx + 1); });
    }

    tryInstance(0);
  });
}

function getSpotifyTrackInfo(url) {
  return new Promise(function(resolve, reject) {
    var oembedUrl = 'https://open.spotify.com/oembed?url=' + encodeURIComponent(url);
    require('https').get(oembedUrl, { headers: { 'User-Agent': 'TwitchSoundBoard/0.2.0' } }, function(resp) {
      if (resp.statusCode !== 200) return reject(new Error('Spotify Track nicht gefunden'));
      var data = '';
      resp.on('data', function(chunk) { data += chunk; });
      resp.on('end', function() {
        try {
          var json = JSON.parse(data);
          resolve({ title: json.title || 'Unknown Track' });
        } catch (e) { reject(new Error('Spotify Antwort unlesbar')); }
      });
    }).on('error', function(err) { reject(new Error('Spotify Fehler: ' + err.message)); });
  });
}

async function importYouTubeVideo(url) {
  var videoId = null;
  var ytMatch = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{6,})/i);
  if (ytMatch) videoId = ytMatch[1];
  if (!videoId) throw new Error('Ungueltige YouTube URL');

  var safeName = 'youtube_' + videoId;
  var filename = Date.now() + '_YT_' + videoId + '_' + safeName + '.mp4';
  var filePath = path.join(VIDEOS_DIR, filename);

  // Versuch 1: Direkt via ytdl (schneller, besser Quality)
  if (ytdl) {
    try {
      var info = await ytdl.getInfo(url);
      var title = info.videoDetails.title;
      var durationSec = parseInt(info.videoDetails.lengthSeconds) || 0;
      safeName = title.replace(/[^a-zA-Z0-9._\- ]/g, '_').substring(0, 60);
      filename = Date.now() + '_YT_' + videoId + '_' + safeName + '.mp4';
      filePath = path.join(VIDEOS_DIR, filename);

      var formats = (info.formats || []).filter(function(f) { return f.hasVideo && f.hasAudio; });
      var mp4Formats = formats.filter(function(f) { return f.container === 'mp4'; });
      var format = mp4Formats.length ? mp4Formats[0] : formats[0];

      if (format) {
        log('INFO', 'YT Direkt-Import: "' + title + '" (' + (format.qualityLabel || format.quality) + ')');
        var stream = ytdl(url, { format: format });
        await saveStreamToFile(stream, filePath);

        if (!config.file_settings) config.file_settings = {};
        config.file_settings[filename] = { display_name: title, duration_ms: 0 };
        saveConfig();
        log('INFO', 'YT Video OK: ' + filename);
        return { filename: filename, title: title, type: 'video', duration_seconds: durationSec, size: fs.statSync(filePath).size, quality: format.qualityLabel || format.quality };
      }
    } catch (directErr) {
      // JEDEN ytdl-Fehler abfangen und Invidious versuchen
      // (age-restricted, format error, login, unavailable, etc.)
      log('WARN', 'YT Direkt fehlgeschlagen: ' + directErr.message + ' → versuche Invidious-Proxy...');
    }
  }

  // Versuch 2: Invidious Proxy (umgeht Altersbeschraenkung)
  log('INFO', 'YT Import via Invidious-Proxy...');
  var result = await downloadViaInvidious(videoId, filePath, 'video');
  var resultExt = path.extname(result.filePath);
  var resultBase = path.basename(result.filePath);

  if (!config.file_settings) config.file_settings = {};
  config.file_settings[resultBase] = { display_name: result.title, duration_ms: 0 };
  saveConfig();

  log('INFO', 'YT Video via Invidious OK: ' + resultBase);
  return {
    filename: resultBase, title: result.title, type: 'video',
    duration_seconds: result.durationSeconds, size: fs.statSync(result.filePath).size,
    quality: result.quality || 'proxy'
  };
}

async function importSpotifyTrack(url) {
  var trackInfo = await getSpotifyTrackInfo(url);
  var searchQuery = trackInfo.title + ' official audio';

  log('INFO', 'Spotify Import: Suche "' + searchQuery + '" auf YouTube...');

  var ytVideo = await searchYouTubeOnInvidious(searchQuery);
  var videoId = ytVideo.videoId;
  log('INFO', 'Spotify Import: YT Treffer "' + ytVideo.title + '" (ID: ' + videoId + ')');

  var safeName = trackInfo.title.replace(/[^a-zA-Z0-9._\- ]/g, '_').substring(0, 60);
  var filePath = path.join(SOUNDS_DIR, Date.now() + '_SPOTIFY_' + safeName + '.m4a');

  // Versuch 1: Direkt via ytdl
  if (ytdl) {
    try {
      var ytUrl = 'https://www.youtube.com/watch?v=' + videoId;
      var info = await ytdl.getInfo(ytUrl);

      var formats = (info.formats || [])
        .filter(function(f) { return f.hasAudio && !f.hasVideo; })
        .sort(function(a, b) { return (b.bitrate || 0) - (a.bitrate || 0); });

      if (formats.length) {
        var format = formats[0];
        var ext = format.container || 'm4a';
        var filename = Date.now() + '_SPOTIFY_' + safeName + '.' + ext;
        filePath = path.join(SOUNDS_DIR, filename);

        var stream = ytdl(ytUrl, { format: format });
        await saveStreamToFile(stream, filePath);

        if (!config.file_settings) config.file_settings = {};
        config.file_settings[filename] = { display_name: trackInfo.title, duration_ms: null };
        saveConfig();

        log('INFO', 'Spotify Track OK (direkt): ' + filename);
        return { filename: filename, title: trackInfo.title, type: 'sound', source: 'spotify', size: fs.statSync(filePath).size };
      }
    } catch (directErr) {
      // JEDEN ytdl-Fehler abfangen und Invidious versuchen
      log('WARN', 'Spotify/YT Direkt fehlgeschlagen: ' + directErr.message + ' → versuche Invidious-Proxy...');
    }
  }

  // Versuch 2: Invidious Proxy
  log('INFO', 'Spotify Import via Invidious-Proxy...');
  var result = await downloadViaInvidious(videoId, filePath, 'audio');
  var resultBase = path.basename(result.filePath);

  if (!config.file_settings) config.file_settings = {};
  config.file_settings[resultBase] = { display_name: trackInfo.title, duration_ms: null };
  saveConfig();

  log('INFO', 'Spotify Track via Invidious OK: ' + resultBase);
  return { filename: resultBase, title: trackInfo.title, type: 'sound', source: 'spotify', size: fs.statSync(result.filePath).size };
}

// ---- Port ----
var PORT = 3000;
var WS_PORT = 3001;
try {
  PORT = parseInt(process.env.PORT) || 3000;
  WS_PORT = parseInt(process.env.WS_PORT) || 3001;
} catch (e) {}

// =============================================
// Express Server
// =============================================
const app = express();
const server = http.createServer(app);

app.use(express.json({ limit: '10mb' }));
app.use('/media/sounds', express.static(SOUNDS_DIR));
app.use('/media/videos', express.static(VIDEOS_DIR));

// =============================================
// API – Media
// =============================================
app.get('/api/sounds', function(req, res) {
  try {
    var fs_cfg = config.file_settings || {};
    var files = fs.readdirSync(SOUNDS_DIR)
      .filter(function(f) { return /\.(mp3|wav|ogg|m4a|webm)$/i.test(f); })
      .map(function(f) {
        var st = fs_cfg[f] || {};
        return { name: f, path: '/media/sounds/' + f, size: fs.statSync(path.join(SOUNDS_DIR, f)).size, duration_ms: st.duration_ms || null, display_name: st.display_name || null };
      });
    res.json(files);
  } catch (e) { res.json([]); }
});

app.get('/api/videos', function(req, res) {
  try {
    var fs_cfg = config.file_settings || {};
    var files = fs.readdirSync(VIDEOS_DIR)
      .filter(function(f) { return /\.(mp4|webm|avi|mov)$/i.test(f); })
      .map(function(f) {
        var st = fs_cfg[f] || {};
        return { name: f, path: '/media/videos/' + f, size: fs.statSync(path.join(VIDEOS_DIR, f)).size, duration_ms: st.duration_ms || null, display_name: st.display_name || null };
      });
    res.json(files);
  } catch (e) { res.json([]); }
});

app.post('/api/upload', function(req, res) {
  if (!upload) return res.status(500).json({ error: 'Upload nicht verfuegbar' });
  upload.array('files', 20)(req, res, function(err) {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.files || !req.files.length) return res.status(400).json({ error: 'Keine Dateien' });
    var out = req.files.map(function(f) {
      var isVid = f.path.indexOf('videos') !== -1;
      return {
        name: f.filename, originalName: f.originalname,
        path: isVid ? '/media/videos/' + f.filename : '/media/sounds/' + f.filename,
        type: isVid ? 'video' : 'sound', size: f.size
      };
    });
    log('INFO', out.length + ' Datei(en) hochgeladen');
    res.json({ uploaded: out });
  });
});

app.delete('/api/media/:type/:filename', function(req, res) {
  var type = req.params.type;
  var filename = decodeURIComponent(req.params.filename);
  var dir = type === 'video' ? VIDEOS_DIR : SOUNDS_DIR;
  var fp = path.join(dir, filename);
  if (fp.indexOf(dir) !== 0) return res.status(403).json({ error: 'Blocked' });
  try {
    fs.unlinkSync(fp);
    for (var k in (config.chat_commands || {})) {
      if (config.chat_commands[k].file === filename) delete config.chat_commands[k];
    }
    if (config.file_settings) delete config.file_settings[filename];
    saveConfig();
    log('INFO', 'Geloescht: ' + filename);
    res.json({ success: true });
  } catch (e) { res.status(404).json({ error: 'Nicht gefunden' }); }
});

// =============================================
// API – File Settings (duration, display_name)
// =============================================
app.put('/api/media/settings', function(req, res) {
  var body = req.body;
  if (!body.filename) return res.status(400).json({ error: 'filename noetig' });
  if (!config.file_settings) config.file_settings = {};
  var f = config.file_settings[body.filename] || {};
  if (body.duration_ms !== undefined && body.duration_ms !== null && body.duration_ms !== '') {
    f.duration_ms = parseInt(body.duration_ms);
  } else if (body.duration_ms === null || body.duration_ms === '') {
    delete f.duration_ms;
  }
  if (body.display_name !== undefined && body.display_name !== null && body.display_name !== '') {
    f.display_name = String(body.display_name);
  } else if (body.display_name === null || body.display_name === '') {
    delete f.display_name;
  }
  if (Object.keys(f).length === 0) {
    delete config.file_settings[body.filename];
  } else {
    config.file_settings[body.filename] = f;
  }
  saveConfig();
  log('INFO', 'Datei-Settings: ' + body.filename + ' -> ' + JSON.stringify(f));
  res.json({ ok: true, settings: f });
});

// =============================================
// API – Config
// =============================================
app.get('/api/config', function(req, res) { res.json(config); });

app.put('/api/config', function(req, res) {
  config = req.body; saveConfig(); broadcast({ type: 'config_reloaded', config: config }); res.json({ ok: true });
});

app.post('/api/config/commands', function(req, res) {
  var body = req.body;
  if (!body.command || !body.file || !body.type) return res.status(400).json({ error: 'Felder fehlen' });
  if (!config.chat_commands) config.chat_commands = {};
  config.chat_commands[body.command] = { file: body.file, type: body.type }; saveConfig();
  broadcast({ type: 'config_reloaded', config: config });
  log('INFO', 'Command "' + body.command + '" -> "' + body.file + '"');
  res.json({ ok: true });
});

app.delete('/api/config/commands/:command', function(req, res) {
  var cmd = decodeURIComponent(req.params.command);
  if (config.chat_commands && config.chat_commands[cmd]) {
    delete config.chat_commands[cmd]; saveConfig();
    broadcast({ type: 'config_reloaded', config: config });
  }
  res.json({ ok: true });
});

app.put('/api/config/settings', function(req, res) {
  config.settings = Object.assign({}, config.settings, req.body); saveConfig();
  broadcast({ type: 'config_reloaded', config: config });
  res.json({ ok: true });
});

// =============================================
// API – Test Trigger
// =============================================
app.post('/api/test-trigger', function(req, res) {
  var body = req.body;
  if (!body.file || !body.type) return res.status(400).json({ error: 'file und type noetig' });
  triggerOverlay(body.file, body.type, 'test', 'Admin');
  res.json({ ok: true });
});

// =============================================
// API – YouTube / Spotify Import
// =============================================
app.post('/api/import', function(req, res) {
  if (!ytdl) return res.status(503).json({ error: 'YouTube-Import nicht verfuegbar. Bitte npm install ausfuehren.' });

  var url = (req.body.url || '').trim();
  if (!url) return res.status(400).json({ error: 'URL noetig' });

  if (isYtUrl(url)) {
    importYouTubeVideo(url).then(function(result) {
      broadcast({ type: 'config_reloaded', config: config });
      res.json({ ok: true, 'import': result });
    }).catch(function(err) {
      log('ERROR', 'YT Import Error: ' + err.message);
      res.status(500).json({ error: err.message });
    });
  } else if (isSpotifyUrl(url)) {
    importSpotifyTrack(url).then(function(result) {
      broadcast({ type: 'config_reloaded', config: config });
      res.json({ ok: true, 'import': result });
    }).catch(function(err) {
      log('ERROR', 'Spotify Import Error: ' + err.message);
      res.status(500).json({ error: err.message });
    });
  } else {
    res.status(400).json({ error: 'Nur YouTube oder Spotify Track Links unterstuetzt' });
  }
});

// =============================================
// API – Credentials
// =============================================
app.get('/api/credentials', function(req, res) {
  var creds = loadCredentials();
  var masked = {};
  for (var k in creds) {
    var v = creds[k];
    if (!v) { masked[k] = ''; }
    else if (k.indexOf('token') !== -1 || k.indexOf('secret') !== -1) {
      masked[k] = v.length > 4 ? '****' + v.slice(-4) : '****';
    } else {
      masked[k] = v;
    }
  }
  var hasAny = false;
  for (var kk in creds) { if (creds[kk]) { hasAny = true; break; } }
  res.json({ masked: masked, hasValues: hasAny });
});

app.put('/api/credentials', function(req, res) {
  var existing = loadCredentials();
  var body = req.body;
  for (var k in body) {
    if (body[k] && typeof body[k] === 'string' && body[k].indexOf('****') !== 0) {
      existing[k] = body[k];
    }
  }
  saveCredentials(existing);
  log('INFO', 'Credentials gespeichert');
  res.json({ ok: true });
});

// =============================================
// API – Twitch Start / Stop (tmi.js)
// =============================================
var chatClient = null;
var twitchRunning = false;

app.get('/api/twitch/status', function(req, res) {
  var creds = loadCredentials();
  res.json({ running: twitchRunning, channel: creds.twitch_channel || null });
});

app.post('/api/twitch/start', function(req, res) {
  if (twitchRunning) return res.status(400).json({ error: 'Laeuft bereits' });

  var creds = loadCredentials();
  if (!creds.twitch_channel) return res.status(400).json({ error: 'Kanalname fehlt' });
  if (!creds.twitch_bot_token) return res.status(400).json({ error: 'Bot-Token fehlt' });

  try {
    var tmi = require('tmi.js');

    // Token bereinigen: "oauth:" Prefix entfernen falls doppelt
    var token = creds.twitch_bot_token;
    if (token.indexOf('oauth:oauth:') === 0) token = token.slice(6);
    if (token.indexOf('oauth:') !== 0) token = 'oauth:' + token;

    var opts = {
      identity: {
        username: creds.twitch_bot_username || creds.twitch_channel,
        password: token
      },
      channels: [creds.twitch_channel]
    };

    chatClient = new tmi.Client(opts);

    chatClient.on('connected', function(addr, port) {
      twitchRunning = true;
      log('INFO', 'Twitch Chat verbunden: #' + creds.twitch_channel);
      res.json({ ok: true, channel: creds.twitch_channel });
    });

    chatClient.on('disconnected', function(reason) {
      twitchRunning = false;
      log('WARN', 'Twitch Chat getrennt: ' + reason);
    });

    chatClient.on('chat', function(channel, userstate, message, self) {
      if (self) return;
      var prefix = (config.settings || {}).command_prefix || '!';
      if (message.indexOf(prefix) === 0) {
        var cmd = message.toLowerCase().split(' ')[0];
        var mapping = config.chat_commands || {};
        if (mapping[cmd]) {
          triggerOverlay(mapping[cmd].file, mapping[cmd].type, 'chat', userstate['display-name'] || 'Viewer');
        }
      }
    });

    chatClient.on('error', function(err) {
      log('ERROR', 'Twitch Chat Fehler: ' + (err.message || JSON.stringify(err)));
    });

    chatClient.connect().catch(function(e) {
      log('ERROR', 'Twitch Chat Connect: ' + e.message);
      if (!twitchRunning) {
        res.status(500).json({ error: e.message || 'Verbindung fehlgeschlagen' });
      }
    });

  } catch (e) {
    log('ERROR', 'Twitch Start: ' + e.message);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/twitch/stop', function(req, res) {
  if (!twitchRunning) return res.status(400).json({ error: 'Laeuft nicht' });
  try {
    if (chatClient) {
      chatClient.disconnect().then(function() {
        chatClient = null;
        twitchRunning = false;
        log('INFO', 'Twitch Chat gestoppt');
        res.json({ ok: true });
      }).catch(function(e) {
        chatClient = null;
        twitchRunning = false;
        res.json({ ok: true });
      });
    } else {
      twitchRunning = false;
      res.json({ ok: true });
    }
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// =============================================
// API – Health
// =============================================
app.get('/api/health', function(req, res) {
  var creds = loadCredentials();
  var sndCount = 0, vidCount = 0;
  try {
    sndCount = fs.readdirSync(SOUNDS_DIR).filter(function(f) { return /\.(mp3|wav|ogg|m4a|webm)$/i.test(f); }).length;
    vidCount = fs.readdirSync(VIDEOS_DIR).filter(function(f) { return /\.(mp4|webm|avi|mov)$/i.test(f); }).length;
  } catch (e) {}
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    version: getVersion(),
    twitch: { running: twitchRunning, channel: creds.twitch_channel || null },
    sounds: sndCount,
    videos: vidCount,
    overlayClients: overlayClients.size
  });
});

// =============================================
// Pages
// =============================================
app.get('/admin', function(req, res) { res.sendFile(path.join(__dirname, 'public', 'admin.html')); });
app.get('/overlay', function(req, res) { res.sendFile(path.join(__dirname, 'public', 'overlay.html')); });
app.get('/', function(req, res) { res.redirect('/admin'); });

// =============================================
// WebSocket (Overlay)
// =============================================
var wss = null;
var overlayClients = new Set();

try {
  wss = new WebSocket.Server({ port: WS_PORT });
  wss.on('error', function(err) {
    if (err.code === 'EADDRINUSE') {
      log('WARN', 'WebSocket-Port ' + WS_PORT + ' belegt, versuche Port ' + (WS_PORT + 1));
      try {
        wss = new WebSocket.Server({ port: WS_PORT + 1 });
        log('INFO', 'WebSocket laeuft auf Port ' + (WS_PORT + 1));
      } catch (e2) {
        log('ERROR', 'WebSocket konnte nicht gestartet werden');
      }
    } else {
      log('ERROR', 'WebSocket: ' + err.message);
    }
  });
} catch (e) {
  log('ERROR', 'WebSocket Init: ' + e.message);
}

if (wss) wss.on('connection', function(ws) {
  log('INFO', 'Overlay verbunden (' + (overlayClients.size + 1) + ')');
  overlayClients.add(ws);
  try { ws.send(JSON.stringify({ type: 'init', config: config })); } catch (e) {}
  ws.on('close', function() { overlayClients.delete(ws); });
  ws.on('error', function() {});
});

function broadcast(data) {
  var msg = JSON.stringify(data);
  overlayClients.forEach(function(c) {
    if (c.readyState === WebSocket.OPEN) {
      try { c.send(msg); } catch (e) {}
    }
  });
}

function triggerOverlay(file, type, source, user) {
  var s = config.settings || {};
  var fs_cfg = (config.file_settings || {})[file] || {};
  var dur;
  if (type === 'video') {
    // duration_ms explizit gesetzt? 0 = ganzes Video, >0 = cut nach X ms
    if (fs_cfg.duration_ms !== undefined && fs_cfg.duration_ms !== null) {
      dur = fs_cfg.duration_ms;
    } else {
      // Nicht pro File gesetzt → globale Video-Default nutzen
      dur = s.video_duration_override_ms || 5000;
    }
  } else {
    // Sound: duration_ms = cut nach X ms, null/undefined = ganzes Audio
    dur = (fs_cfg.duration_ms != null && fs_cfg.duration_ms > 0) ? fs_cfg.duration_ms : null;
  }
  broadcast({
    type: 'play', file: file, mediaType: type, source: source, user: user || 'System',
    volume: type === 'video' ? (s.video_volume || 0.5) : (s.sound_volume || 0.8),
    allowOverlap: s.allow_overlap || false, maxQueue: s.max_queue_size || 10,
    durationOverride: dur
  });
  log('INFO', 'Trigger: ' + type + ' "' + file + '" von ' + user + ' (' + source + ')');
}

// =============================================
// Helpers
// =============================================
function getVersion() {
  try { return fs.readFileSync(path.join(__dirname, 'VERSION'), 'utf-8').trim(); }
  catch (e) { return '0.0.0'; }
}

// Graceful Shutdown
process.on('SIGINT', function() {
  log('INFO', 'Shutdown...');
  try { if (chatClient) chatClient.disconnect(); } catch (e) {}
  try { server.close(); } catch (e) {}
  try { if (wss) wss.close(); } catch (e) {}
  process.exit(0);
});

// =============================================
// START
// =============================================
console.log('');
console.log('========================================');
console.log('  TwitchSoundBoard v' + getVersion());
console.log('========================================');

server.listen(PORT, function() {
  console.log('  Admin:    http://localhost:' + PORT + '/admin');
  console.log('  Overlay:  http://localhost:' + PORT + '/overlay');
  console.log('========================================');
  log('INFO', 'Server laeuft - oeffne http://localhost:' + PORT + '/admin');
  console.log('');
});
